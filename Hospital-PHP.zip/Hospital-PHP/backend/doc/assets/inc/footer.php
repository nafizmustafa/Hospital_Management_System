<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
              Hospital Management Information System. Developed By Md Nafiz Mustafa
            </div>

        </div>
    </div>
</footer>