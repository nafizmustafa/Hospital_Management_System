<footer class="footer footer-alt">
             Hospital Management System. Developed By Md Nafiz Mustafa
</footer>