<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
               Hospital Management System. Developed By Md Nafiz Mustafa</a>
            </div>

        </div>
    </div>
</footer>